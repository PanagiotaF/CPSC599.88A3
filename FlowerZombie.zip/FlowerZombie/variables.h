// States
int countButtonState = 0;
int countLastButtonState = 0; 
int resetButtonState = 0;
int resetLastButtonState = 0; 
int resetState = false;

// Counters
int count = 0;
int cupCount = 0;
